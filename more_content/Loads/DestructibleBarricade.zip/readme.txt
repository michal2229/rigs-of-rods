DESTRUCTIBLE BARRICADE

=====

I. Installation
II. Information
III. Credits

=====

I. Installation

Place the provided .ZIP into My Documents > Rigs of Rods > Packs.
(note: copy-and-paste %USERPROFILE%\My Documents\Rigs of Rods to get there quicker [Windows users]).

II. Information

This load is designed ultimately to be placed on terrains as scenery, and penultimately to be 
destroyed by ramming it with something of great mass. You may use a crane to pick it up, and a 
truck/trailer to transport it, but bear in mind that this load is fragile.

Feel free to use this in your maps or mods so long as proper credits are given. I have also given 
this a GUID(21f81cd1-294f-4149-8b97-386f5c3ebe1d) so you can skin it and release that skin(If you wish to).

III. Credits

Beolex - mesh and textures
Oxsergy - N/B and refinement

Blender 2.49 - mesh creation/completion
Adobe Photoshop CS3 - texturing/image editing
CG Textures - ultimate source for textures

=====



