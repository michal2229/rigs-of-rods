Don't sell or redistribute this model
Exclusive download at http://www.rigsofrods.com/repository/
Don't modify without my permission

T42
http://www.rigsofrods.com/private.php?do=newpm&u=21813