Atlas class tug & unpropelled barges
by Redeye

This pack includes the 'Atlas' class tugboat for Rigs of Rods (version 0.38.67) and 3 different unpropelled barges designed to work with the tug.

The Atlas tug features:
- Nav Lights (Ctrl+1)
- A pair of rear hooks (F9/F10) designed to link to the barges (L).
- A main hook (F11/F12) that can link to most other loads or boats (also L).
- 4 skins
- Works with the .skinzip system

The barges feature:
- An empty generic barge (100 tons)
- A loaded bulk barge (425 tons)
- A liquid goods barge (300 tons)
- Pairs of hooks on each end (F1/F2 and F3/F4) that can link to the tug or other barges
- If two barges are lined up and close enough to one another, they will link automatically (Alt+L to unlink)

Here's a quick tutorial of how to best dock the tug with a barge:
- Spawn a barge and an Atlas tug and line up with a barge. That should get you used to  the tug's controls. Keep an easy hand on the steering wheel, she's slightly nervous.
- Extend your rear hooks a bit (F10), that'll make things easier. Not too much though.
- Add some reverse throttle and back up towards the barge slowly and carefully. Keep an easy hand on the throttle.
- If you're really close to the barge (and still lined up), bring the tug to a halt. Once stopped, hit "L" and wait for the ropes to link up.
- Now extend your rear hooks further for some safety margin between the Atlas and the barge. Congratulations, you're ready to go.

If you want to release a mod of the Atlas or barges, follow 2 simple rules:
- Credit the original author (or authors, if you're modding a mod)
- NO conflicts with the original version! Change all material names, mesh names, texture names, give it an all-new UID and GUID.

If you just want to make a skin for the Atlas or barges, make a *.skinzip. After all, that's precisely what the system was designed for. The good news is you won't have to worry about conflicts with the original.

Have fun!
Redeye