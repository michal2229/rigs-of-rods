This is an update of the wahoo boat, originally made by pricorde. It is not finished.

You may mod/finish this vehicle, as long as you credit Metalmuncher for work on textures, meshes and the node and beam.

--Metalmuncher