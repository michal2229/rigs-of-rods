Placments are same as the other chevies

New mesh names:

K3500HD_Grille.mesh
K3500HD_CabLights.mesh
K3500HD_Cab.mesh
K3500HD_Hood.mesh
K3500HD_Chassis.mesh
K3500HD_FAxle.mesh
K3500HD_RAxle.mesh
K3500HD_FenderFlares.mesh
K3500HD_Bumper.mesh
K3500HD_FLeaf.mesh
K3500HD_RLeaf.mesh
Engine_Bay.mesh
Engine_454.mesh
Kodiak_Interior.mesh
Kodiak_Windows.mesh
K3500_TowMirrors.mesh





New materials:

managedmaterials
set_managedmaterials_options 1

;K3500HD		mesh_standard		K3500HD.png			K3500HD_S.png
K3500HD_Frame		mesh_standard		K3500HD_Frame.png		K3500HD_Frame_S.png
K3500HD_FenderFlares	mesh_standard		K3500HD_FenderFlares.png	-
K3500HD_FrontPlastics	mesh_standard		K3500HD_FrontPlastics.png	K3500HD_FrontPlastics_S.png

Grille_WT		mesh_standard		Grille_WT.png			Grille_WT_S.png
Kodiak_Interior		mesh_standard		Kodiak_Interior.png		-
Kodiak_Windows		mesh_transparent	Kodiak_Windows.png		Kodiak_Windows_s.png
Kodiak_Mirrors		mesh_standard		Mirrors-Tex.png			Mirrors-Tex.png
BK3500			mesh_standard		K3500-Tex.png			K3500_S.png
K3500_SteeringWheel	mesh_standard		K3500_SteeringWheel.png		-
Engine_Bay		mesh_standard		Engine_Bay.png			Engine_Bay_S.png
Engine_454		mesh_standard		Engine_454.png			Engine_454_S.png







