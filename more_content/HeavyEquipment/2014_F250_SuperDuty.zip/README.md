Official development repo for the 2014 Ford F-250 Super Duty XLT - http://forum.rigsofrods.org/thread-1022.html

Current credits:
- Stoat Muldoon - Original truck
- AdolfoPineda - Textures
- DarthCain - Interior
- negativeice  - Steering wheel/Needles/Tires
- James2406 - Dashboard
- Sean - Sounds
- Venomox - Tow hitch
- 4x4convoy - Single cab mesh edits
- Lifter - Improved node renumberer, made single cab version possible
- The Wolf - Gooseneck hitch
- Michael10055 (Myself) - Everything else

__**I do not want to see any content from this used in other games.**__