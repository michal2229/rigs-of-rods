===========================
best graphics settings
===========================
on my computer the best graphics settings for over all look and framerate, change 
sightrange to about 3000 m, turn off high quality reflections, mirrors, hdr, dof and 
in advanced tab change light source effects to Only currant vehicle, main lights.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
i have included my enbseries settings in this zip, it makes the bloom effect look better and washes out the colors a bit, for anyone wanting to use it just drop the dxd9.dll and enbseries.ini into your rigs of rods folder where the ror.exe is, use shift key plus F12 to turn it on and off, if you dont want to use it just dont put it in you ror.exe dir. and to uninstall it just delete the dxd9.dll and enbseries.ini from your ror.exe dir.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

System Requirements: ( has been tested on )
=========================
rigs of rods version 0.38.67
windows xp or 7
512 / 1024 mb videocard
up to date sound drivers and DirectX ( DXSDK_Feb10.exe )
2 or 4 GB of ddr
3 GHz dual Core Processor

=========================
Recommended:        ( has been tested on )
=========================
rigs of rods version 0.38.67
windows 7
1024 / 2048 mb videocard
up to date sound drivers and DirectX ( DXSDK_Feb10.exe )
4 or 8 GB of ddr
3 GHz six Core Processor


=========================

all of the ground textures, sand, grass, gravel, rock, dirt and so on where made by me, used photos that i have taken over the years to make those and i used L3DT and crazybump to make the normal maps for those, feel free to use them in your own project (for rigs of rods only please) if you wish. just give credit in a readme.
i used the sample ETShader.program to get all the normal mapping (bump mapping ) to work, i optimized it to be used on the buildings, rocks and trees that i modeled also.

anything that is in this .zip file can be used in rigs of rods freely but is not to be sold. ever!

=========================
more credit:
=========================

signs and truckshop i guess comes with rigs of rods ?

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

================
Animation Credit
================

haselnut116601 from the Ror forums for the cat 330c animation, the (ashes48_330c.skeleton) very cool stuff! and i think this will open something new up to new terrains :D

================
textures credits
================

cgtextures.com for the cliff rock texture and tall grass texture.
fall_run01.dds
fall_run08.dds ( i think! )
fall_run09.dds ( i think! )

------------------------------------------------------------------
http://opengameart.org/content/plants-textures-pack-04
fall_run06.dds

=========================
beta testers and sujestions
=========================
BigC92
qwerty
pullunit22
J.R
also everyone from http://www.rigsofrods.com/threads/111343-Fall-Run?p=1285313#post1285313 for downloading testing it! :)

=========================
tools used
=========================
Kodak easyshare c613 camera
L3DT
crazybump
paint
paint.net
iphoto plus
RoR Tool Kit 0.38
tree[d]
zmodeler
BlenderPortable
ArtifexTerra3D
=========================
my info:
ashes48@yahoo.com
ashes48 on rigs of rods site or just google ashes48 to know more about me :)
if you need help with anything like textures or sound in any project just ask and i'll do what i can.

thanks to all on my wip forum on my terrains for help on questions i had! and for sujestions to make these terrains better, im sure i'll have more questions come :P

==========================
i'd like to thank and credit haselnut116601 from the rigs of rods forums for helping me with the garage truck spawner, i had problems getting it to work on my own :)


