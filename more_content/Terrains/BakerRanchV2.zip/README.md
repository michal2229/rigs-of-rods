# Baker Ranch V2

Remaking the classic Baker Ranch terrain for Rigs of Rods.

# Current credits:

- Box5diesel = Original terrain
- Klink = 0.4 convert 
- Michael10055 = Minor fixes/RGB images/Paged geo/etc
- hagdervriese = `vriesen_barn` and `stevington-mill` object
- ashes48 = Some terrain textures
- Masa = Dirt texture
- Charger = Grass texture
- DarthCain = Caseys gas station and `oldtowshop` object
- Austin = `Farmfence`,`Bakersign`,`Farmpowerline`,`Farmlumbersign` objects 
- VeyronEB = `rallyhouse1` and `logcabinrally` objects
- DeGa = `RoR-flag` object
- derbymutt = `DI_SPORT_WRECK` objects
- Brett = `BK-Building2` object


# Download

The latest zip can be found on AppVeyor: 

https://ci.appveyor.com/project/Michael10055/baker-ranch-v2/build/artifacts

**NOTE: It is recommnded to disable PSSM (shadows) as the sand layer will be missing with it on.**
