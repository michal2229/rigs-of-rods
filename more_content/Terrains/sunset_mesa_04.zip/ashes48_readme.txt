===========================
best graphics settings
===========================
on my computer the best graphics settings for over all look and framerate, change 
sightrange to full, turn off high quality reflections, mirrors, hdr, dof and 
in advanced tab change light source effects to Only currant vehicle, main lights.
================================================

sunset_mesa was inspired by the 1998 game Viper racing developed by MGI. 
viper racing was also one of the first game i made mods for (cars)
after looking through binary code for nearly 4 years and building cars for this game i spoke to Dave Broska and Dave Pollatsek ( MGI guys ) via email and got the cpp and tools so that we the community could build most anything for the game like sfx, trk, car, and so on,
a team of modders including myself started viper racing VRGT, you can find this at VRGT.com you can download cars, tracks and patches that we have created many years ago.

================================================


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
i have included my enbseries settings in this zip, it makes the bloom effect look better and washes out the colors a bit, for anyone wanting to use it just drop the dxd9.dll and enbseries.ini into your rigs of rods folder where the ror.exe is, use shift key plus F12 to turn it on and off, if you dont want to use it just dont put it in you ror.exe dir. and to uninstall it just delete the dxd9.dll and enbseries.ini from your ror.exe dir.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

System Requirements: ( has been tested on )
=========================
rigs of rods version 0.38.67
windows xp or 7
512 / 1024 mb videocard
up to date sound drivers and DirectX ( DXSDK_Feb10.exe )
2 or 4 GB of ddr
3 GHz dual Core Processor

=========================
Recommended:        ( has been tested on )
=========================
rigs of rods version 0.38.67
windows 7
1024 / 2048 mb videocard
up to date sound drivers and DirectX ( DXSDK_Feb10.exe )
4 or 8 GB of ddr
3 GHz six Core Processor

=========================
all of the ground textures, sand, grass, gravel, rock, dirt and so on where made by me, used photos that i have taken over the years, i used L3DT and crazybump to make the normal maps for those, feel free to use them in your own project (for rigs of rods only please) if you wish. just give me credit in a readme.
i used the sample ETShader.program to get all the normal mapping to work, i used it on the buildings, rocks and trees that i have modeled also. 
note: some textures for this terrain are from cgtextures.com
=========================
more credit:
=========================
LJ-DN-SmallTree-01 from LJFHutch
signs and truckshop i guess comes with rigs of rods ?

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

cgtextures.com  for these textures, they were edited by me to work 
with this terrain.

test1_cliffrock.dds
sunset_mesa01.dds
sunset_mesa03.dds
test1_dirt2.dds
test1_dirt.dds
test1_lushgrass.dds
test1_drygrass2.dds
test1_mud.dds

====================================
background image i used in sunset_mesa is from this site
 
http://commons.wikimedia.org/wiki/File:Arches_Nationalpark_primitive_trail_view_to_Devils_Garden.jpg

licensing info about the image.

"This file is licensed under the Creative Commons Attribution-Share Alike 3.0 Unported license.

You are free: to share � to copy, distribute and transmit the work
to remix � to adapt the work
Under the following conditions: attribution � You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
share alike � If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one.

This licensing tag was added to this file as part of the GFDL licensing update."

==========================
the song in the gas station is a cover song "simple man" by my cousin Keith Scarberry on facebook, https://www.facebook.com/#!/photo.php?v=855137711178779&set=vb.100000476739158&type=2&theater he's really good at singing and playing and he has given me permission to use his cover song in the gas station. 

============================================
beta testers, suggestions and help with bugs
============================================

BigC92
and some of BigC92 friends ( unsure of what their names are :) )
also the people on the Rigs of Rods forums.

big thanks to disloyalpick from the ror forums for helping me with the sound bug i was having.
heres how to make sure all the sounds work.

( quoting disloyalpick) 

"When you load the game after it crashes, and it has no sounds, try clicking the simulation menu button and click Activate all Vehicles. I had the bug of sounds not loading on some terrains before, and doing that made the sounds work."


=========================
tools used
=========================
Kodak easyshare c613 camera
L3DT
crazybump
paint
paint.net
iphoto plus
RoR Tool Kit 0.38
tree[d]
zmodeler
BlenderPortable
=========================
my info:
ashes48@yahoo.com
ashes48 on rigs of rods site or just google ashes48 to know more about me :)
if you need help with anything like textures or sound in any project just ask and i'll do what i can.

thanks to all on my W.I.P. forum on my terrains for help on questions i had and suggestions! 
im sure i'll have many more to come :P
