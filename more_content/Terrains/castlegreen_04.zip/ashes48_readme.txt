===========================
best graphics settings
===========================
on my computer the best graphics settings for over all look and framerate, change 
sightrange to about 3000 m, turn off high quality reflections, mirrors, hdr, dof and 
in advanced tab change light source effects to Only currant vehicle, main lights.


castlegreen was inspired by the 1998 game Viper racing developed by MGI. 
viper racing was also one of the first game i made mods for (cars)
after looking through binary code for nearly 4 years and building cars for this game i spoke to Dave Broska and Dave Pollatsek via email and got the cpp to build most anything for the game like sfx, trk, car, and so on for the game.
a team of modders including myself started viper racing VRGT, you can find this at VRGT.com you can download cars, tracks and patches that we have created many years ago.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
i have included my enbseries settings in this zip, it makes the bloom effect look better and washes out the colors a bit, for anyone wanting to use it just drop the dxd9.dll and enbseries.ini into your rigs of rods folder where the ror.exe is, use shift key plus F12 to turn it on and off, if you dont want to use it just dont put it in you ror.exe dir. and to uninstall it just delete the dxd9.dll and enbseries.ini from your ror.exe dir.
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

System Requirements:
=========================
rigs of rods version 0.38.67


=========================
Recommended: 
=========================
rigs of rods version 0.38.67


=========================
all of the ground textures, sand, grass, gravel, dirt and so on where made by me, used photos that i have taken over the years to make those and i used L3DT and crazybump to make the normal maps for those, feel free to use them in your own project (for rigs of rods only please) if you wish. just give credit in a readme.
i used the sample ETShader.program to get all the normal mapping to work, i used it on the buildings, rocks and trees that i modeled also.
=========================
more credit:
=========================

MGI and Owen Justice for the viper racing version of Castlegreen.
LJFHutch, LJ-DN-SmallTree-01 (i changed the colors a little so that they match this terrain)
signs, truckshop and marina i guess comes with rigs of rods ?
some of the houses from haeuser.zip that i found in repository in downloads made by Betzi.

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//ENBSeries is a set of graphical modifications for games
//Description on the web page may not be equal to this info.
//created by Boris Vorontsov http://enbdev.com
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

cgtextures.com for the cliff rock texture test1_cliffrock.dds

=========================
tools used
=========================
Kodak easyshare c613 camera
iphoto plus
L3DT
crazybump
paint
paint.net
RoR Tool Kit 0.38
tree[d]
BlenderPortable
ArtifexTerra3D to do a better blend on the RGB textures
=========================
my info:
ashes48@yahoo.com
ashes48 on rigs of rods site or just google ashes48 to know more about me :)
if you need help with anything like textures or sound in any project just ask and i'll do what i can.
i do not have internet myself but i do try and get online once a week or when i can.

thanks to all on my wip forum on my castlegreen terrain for help on questions i had! im sure i'll have more to come :P
