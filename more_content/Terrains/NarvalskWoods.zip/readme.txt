Credits:

LJFHutch for the trees and the Caleum settings
VeyronEB for the beautiful houses
LJFHutch for the Caleum settings
Me for making the map

And if you have lag on you computer while playing in this map, don't whine about it in the thread.
I will not make an FPS-version of this map.

Have fun!