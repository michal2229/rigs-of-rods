Gavril MZ2 by Gabester

Please do not modify this except for personal use. Thank you.