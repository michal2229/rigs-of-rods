Gavril Omega by Gabester

Please don't make ugly mods of this. Thanks.