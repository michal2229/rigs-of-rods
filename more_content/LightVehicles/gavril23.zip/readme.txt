Gavril G2/G2S by Gabester

Please don't make ugly mods of this. Thanks.