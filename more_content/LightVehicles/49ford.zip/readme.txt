1949 Ford for Rigs of Rods
by Gabester

please don't modify this without my permission