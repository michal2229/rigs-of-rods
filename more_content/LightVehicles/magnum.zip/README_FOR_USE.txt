===================================================
Soon to come: adding skins for others to download.
===================================================
when you have made a skin for any of the magnums that you want to upload to http://www.rigsofrods.com,
i ask that you only upload the .truck files (that you made the skin for) along with the textures and .material (if it has one) in a zip file called magnum_skin_yourskinNamehere.zip
do not edit the .truck files other than adding to the skin sections for uploading, 
you can moddify it all you want for personal use, or even e-mail it to a friend. if many people make skins for it this will keep it clean and a small download. thanks!

when someone wants to install a skin they can just copy the files from your magnum_skin_yourskinNamehere.zip over into their magnum.zip in Documents/Rigs of Rods 0.XX

===================================================
===================================================
first! about skins, the magnum is still in beta testing and im changing the way skins are added. you can give your skins to friends if you want but do not upload for people to download yet, thanks. (the skin section is unfinished)

this is my first car for RoR. :) 
first off, thanks to Gabester for letting me use his nodes / beams from the gavrilzeta.zip ( my eyes mess with me when trying to build this in rorEditor, plus that saved me months of work)! he has everthing well grouped and labled.
many many thanks to Gouranga for the help with understanding the engine torque, engoption and torquecurve sections


the car was baced on the 2005/2006 Dodge Magnum SRT8 dubcity toy car i had once.
i made the model, textures and sounds for a game called street legal racing redline a few years ago and converted it to rigs of rods.
also like to credit RedHorizon for help with the police lights, press ctrl 1 to turn those on.
===================================================
you have my permission to make and upload skins (textures) after the magnum has been finished, for rigs of rods and street legal racing redline games only (if you play that one too)

you have my permission to use the rims in this zip (magnum.zip) on your own rigs of rods vehicles, just 
give credit in a readme.txt

you have my permission to modify and use the sounds that are in this zip (magnum.zip) on your own rigs of rods vehicles, just give credit in a readme.txt

you have my permission to modify and use the engine, engoption and torquecurve settings from any of the magnums in your own project.

you will have to ask Gabester from http://www.rigsofrods.com for permission on the node/beam sections in any of the magnum.truck files.

===================================================
tools used:

zmodeler v1.07b for modeling
iphoto plus for textures
paint.net for converting textures to dds
blender 2.49b for converting to ogre mesh format
cooledit96 for recording and editing sounds.
Cooledit Pro for recording and editing new sounds.

===================================================
credits:

Gabester, for letting me use his nodes / beams from the gavrilzeta.zip

RedHorizon for help with the police lights.

http://www.sonory.org/download-samples.html for the new v8 sound in my moparv8exhaust2 drifter.

===================================================

ashes48 

if you have any suggestions or find bugs, PM me or post them on my forum thread.
if you need help with anything that you think i can help you with in your own projects
PM me or e-mail me at ashes48@yahoo.com.

and thanks to all that have helped on the forum thread with questions i had.

====================================================
a short list of games i have created mods for
viper racing
quake 3 arena
street legal
street legal redline racing
tes morrowind (none online)
tes oblivion (none online)
gta4 (none online)
crysis (none online)
