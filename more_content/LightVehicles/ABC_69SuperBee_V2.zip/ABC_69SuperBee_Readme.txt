1969 Dodge Super Bee 440 6 Pack


If you want to reach me, my email is dkutch_69@hotmail.com.


Do not edit the MESH in any way shape or form without my permission. If you want to use
the n/b all I ask is that you PLEASE consult with me first. Public or private. You are free
to make custom colors, change the motor, wheels, etc. But do not edit the verts on anything
here in this zip.

Credits:

darn_it: Main 440 engine and U-joints
eclipse/faustknight: Rear Dana 60
Tenderpaws: Transmission
ADR's Carmageddon 2 cars: Some textures
Mythbuster: Support, a lot of testing, and being there for rebounding ideas.
Jaw-4: Testing, support, and being someone to talk to. :D
PRT-Audiman: Turbo sounds on the tuned version
Skyhawk: Mini's
Jaimswallace: Awesome teaser video
Dkutch: Everything else.

Thanks to my beta testers:
97Ram1500
Creak
Dennis-W
Jaw-4
Marlou
Micracer
Mythbuster
Nadeox1
Off-Roader
RockCrwlr
ShawnVallance
Silvermanblue
Skyhawk
Straubz
Tmf45

Thanx for your download, and Enjoy!

2013