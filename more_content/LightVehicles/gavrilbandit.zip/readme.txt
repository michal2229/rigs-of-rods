Gavril Bandit by Gabester

Do not modify this except for personal use. I will not grant permission to release any mods or skins of this car.